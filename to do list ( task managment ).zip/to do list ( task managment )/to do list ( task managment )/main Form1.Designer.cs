﻿namespace to_do_list___task_managment__
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            this.calendar = new DevExpress.XtraEditors.Controls.CalendarControl();
            this.sidebar = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelMenu = new System.Windows.Forms.Label();
            this.MenuButton = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonHome = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonSetting = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonHelp = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.buttonAbout = new System.Windows.Forms.Button();
            this.sidebartimer = new System.Windows.Forms.Timer(this.components);
            this.fadeline = new DevExpress.XtraEditors.SeparatorControl();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddButton = new DevExpress.XtraEditors.SimpleButton();
            this.DeleteButton = new DevExpress.XtraEditors.SimpleButton();
            this.Allbutton = new DevExpress.XtraEditors.SimpleButton();
            this.projectbutton = new DevExpress.XtraEditors.SimpleButton();
            this.workbutton = new DevExpress.XtraEditors.SimpleButton();
            this.Universitybutton = new DevExpress.XtraEditors.SimpleButton();
            this.Personalbutton = new DevExpress.XtraEditors.SimpleButton();
            this.buttonAll = new System.Windows.Forms.Button();
            this.managebutton = new System.Windows.Forms.Button();
            this.completebutton = new System.Windows.Forms.Button();
            this.Pendingbutton = new System.Windows.Forms.Button();
            this.separatorControl1 = new DevExpress.XtraEditors.SeparatorControl();
            this.todobutton = new System.Windows.Forms.Button();
            this.searchControl1 = new DevExpress.XtraEditors.SearchControl();
            ((System.ComponentModel.ISupportInitialize)(this.calendar.CalendarTimeProperties)).BeginInit();
            this.sidebar.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MenuButton)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fadeline)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.separatorControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchControl1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // calendar
            // 
            this.calendar.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.calendar.Appearance.BackColor = System.Drawing.Color.White;
            this.calendar.Appearance.BackColor2 = System.Drawing.Color.White;
            this.calendar.Appearance.BorderColor = System.Drawing.Color.White;
            this.calendar.Appearance.Font = new System.Drawing.Font("Tahoma", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.Appearance.ForeColor = System.Drawing.SystemColors.Menu;
            this.calendar.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.calendar.Appearance.Options.UseBackColor = true;
            this.calendar.Appearance.Options.UseBorderColor = true;
            this.calendar.Appearance.Options.UseFont = true;
            this.calendar.Appearance.Options.UseForeColor = true;
            this.calendar.AutoSize = false;
            this.calendar.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.calendar.CalendarAppearance.Button.BackColor = System.Drawing.Color.DimGray;
            this.calendar.CalendarAppearance.Button.FontSizeDelta = 4;
            this.calendar.CalendarAppearance.Button.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.Button.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.calendar.CalendarAppearance.Button.Options.UseBackColor = true;
            this.calendar.CalendarAppearance.Button.Options.UseFont = true;
            this.calendar.CalendarAppearance.Button.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.ButtonHighlighted.ForeColor = System.Drawing.Color.White;
            this.calendar.CalendarAppearance.ButtonHighlighted.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.ButtonPressed.ForeColor = System.Drawing.Color.White;
            this.calendar.CalendarAppearance.ButtonPressed.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.CalendarHeader.Font = new System.Drawing.Font("Tahoma", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.CalendarHeader.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.CalendarHeader.ForeColor = System.Drawing.Color.Red;
            this.calendar.CalendarAppearance.CalendarHeader.Options.UseFont = true;
            this.calendar.CalendarAppearance.CalendarHeader.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.DayCell.BackColor = System.Drawing.Color.White;
            this.calendar.CalendarAppearance.DayCell.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCell.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCell.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.calendar.CalendarAppearance.DayCell.Options.UseBackColor = true;
            this.calendar.CalendarAppearance.DayCell.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCell.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.DayCellDisabled.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellDisabled.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellHighlighted.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellHighlighted.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellHighlighted.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellHoliday.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellHoliday.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellHoliday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.CalendarAppearance.DayCellHoliday.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellHoliday.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.DayCellInactive.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellInactive.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellInactive.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.calendar.CalendarAppearance.DayCellInactive.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellInactive.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.DayCellPressed.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellPressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellPressed.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellSelected.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellSelected.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellSelected.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.calendar.CalendarAppearance.DayCellSelected.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellSpecial.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellSpecial.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellSpecial.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellSpecialHighlighted.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellSpecialHighlighted.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellSpecialHighlighted.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellSpecialPressed.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellSpecialPressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellSpecialPressed.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellSpecialSelected.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellSpecialSelected.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellSpecialSelected.Options.UseFont = true;
            this.calendar.CalendarAppearance.DayCellToday.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.DayCellToday.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.DayCellToday.Options.UseFont = true;
            this.calendar.CalendarAppearance.Header.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.Header.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.Header.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.CalendarAppearance.Header.Options.UseFont = true;
            this.calendar.CalendarAppearance.Header.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.HeaderHighlighted.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.HeaderHighlighted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.CalendarAppearance.HeaderHighlighted.Options.UseFont = true;
            this.calendar.CalendarAppearance.HeaderHighlighted.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.HeaderPressed.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.HeaderPressed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.CalendarAppearance.HeaderPressed.Options.UseFont = true;
            this.calendar.CalendarAppearance.HeaderPressed.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.WeekDay.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calendar.CalendarAppearance.WeekDay.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.WeekDay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.calendar.CalendarAppearance.WeekDay.Options.UseFont = true;
            this.calendar.CalendarAppearance.WeekDay.Options.UseForeColor = true;
            this.calendar.CalendarAppearance.WeekNumber.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.calendar.CalendarAppearance.WeekNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.calendar.CalendarAppearance.WeekNumber.Options.UseFont = true;
            this.calendar.CalendarAppearance.WeekNumber.Options.UseForeColor = true;
            this.calendar.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.calendar.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Classic;
            this.calendar.CaseMonthNames = DevExpress.XtraEditors.Controls.TextCaseMode.UpperCase;
            this.calendar.ContextButtonOptions.BottomPanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.ContextButtonOptions.CenterPanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.ContextButtonOptions.FarPanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.ContextButtonOptions.NearPanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.ContextButtonOptions.TopPanelColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(140)))), ((int)(((byte)(158)))));
            this.calendar.Cursor = System.Windows.Forms.Cursors.Default;
            this.calendar.DateTime = new System.DateTime(((long)(0)));
            this.calendar.EditValue = new System.DateTime(((long)(0)));
            this.calendar.FirstDayOfWeek = System.DayOfWeek.Saturday;
            this.calendar.HighlightTodayCell = DevExpress.Utils.DefaultBoolean.True;
            this.calendar.Location = new System.Drawing.Point(85, 4);
            this.calendar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.calendar.MaxValue = new System.DateTime(2100, 8, 6, 0, 0, 0, 0);
            this.calendar.Name = "calendar";
            this.calendar.Padding = new System.Windows.Forms.Padding(0);
            this.calendar.RightToLeftLayout = DevExpress.Utils.DefaultBoolean.False;
            this.calendar.ShowTodayButton = false;
            this.calendar.ShowWeekNumbers = true;
            this.calendar.ShowYearNavigationButtons = DevExpress.Utils.DefaultBoolean.True;
            this.calendar.Size = new System.Drawing.Size(380, 354);
            this.calendar.TabIndex = 2;
            this.calendar.DateTimeChanged += new System.EventHandler(this.calendarControl1_DateChanged);
            this.calendar.Click += new System.EventHandler(this.calendarControl2_Click);
            // 
            // sidebar
            // 
            this.sidebar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(41)))), ((int)(((byte)(44)))));
            this.sidebar.Controls.Add(this.panel1);
            this.sidebar.Controls.Add(this.panel2);
            this.sidebar.Controls.Add(this.panel3);
            this.sidebar.Controls.Add(this.panel4);
            this.sidebar.Controls.Add(this.panel6);
            this.sidebar.Cursor = System.Windows.Forms.Cursors.Default;
            this.sidebar.ForeColor = System.Drawing.Color.White;
            this.sidebar.Location = new System.Drawing.Point(0, -1);
            this.sidebar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sidebar.MaximumSize = new System.Drawing.Size(244, 1088);
            this.sidebar.MinimumSize = new System.Drawing.Size(76, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(76, 1068);
            this.sidebar.TabIndex = 3;
            this.sidebar.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelMenu);
            this.panel1.Controls.Add(this.MenuButton);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(243, 122);
            this.panel1.TabIndex = 4;
            // 
            // labelMenu
            // 
            this.labelMenu.AutoSize = true;
            this.labelMenu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMenu.Location = new System.Drawing.Point(92, 42);
            this.labelMenu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelMenu.Name = "labelMenu";
            this.labelMenu.Size = new System.Drawing.Size(66, 28);
            this.labelMenu.TabIndex = 4;
            this.labelMenu.Text = "Menu";
            // 
            // MenuButton
            // 
            this.MenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MenuButton.Image = ((System.Drawing.Image)(resources.GetObject("MenuButton.Image")));
            this.MenuButton.Location = new System.Drawing.Point(12, 33);
            this.MenuButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MenuButton.Name = "MenuButton";
            this.MenuButton.Size = new System.Drawing.Size(43, 43);
            this.MenuButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.MenuButton.TabIndex = 4;
            this.MenuButton.TabStop = false;
            this.MenuButton.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttonHome);
            this.panel2.Location = new System.Drawing.Point(3, 128);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(243, 46);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // buttonHome
            // 
            this.buttonHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(41)))), ((int)(((byte)(44)))));
            this.buttonHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonHome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.White;
            this.buttonHome.Image = ((System.Drawing.Image)(resources.GetObject("buttonHome.Image")));
            this.buttonHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHome.Location = new System.Drawing.Point(-11, -12);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.buttonHome.Size = new System.Drawing.Size(261, 71);
            this.buttonHome.TabIndex = 7;
            this.buttonHome.Text = "               Home";
            this.buttonHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.buttonSetting);
            this.panel3.Location = new System.Drawing.Point(3, 178);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(243, 46);
            this.panel3.TabIndex = 6;
            // 
            // buttonSetting
            // 
            this.buttonSetting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(41)))), ((int)(((byte)(44)))));
            this.buttonSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSetting.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSetting.ForeColor = System.Drawing.Color.White;
            this.buttonSetting.Image = ((System.Drawing.Image)(resources.GetObject("buttonSetting.Image")));
            this.buttonSetting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSetting.Location = new System.Drawing.Point(-9, -14);
            this.buttonSetting.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonSetting.Name = "buttonSetting";
            this.buttonSetting.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.buttonSetting.Size = new System.Drawing.Size(261, 71);
            this.buttonSetting.TabIndex = 8;
            this.buttonSetting.Text = "               Setting";
            this.buttonSetting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSetting.UseVisualStyleBackColor = false;
            this.buttonSetting.Click += new System.EventHandler(this.buttonSetting_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.buttonHelp);
            this.panel4.Location = new System.Drawing.Point(3, 228);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(243, 46);
            this.panel4.TabIndex = 7;
            // 
            // buttonHelp
            // 
            this.buttonHelp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(41)))), ((int)(((byte)(44)))));
            this.buttonHelp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonHelp.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHelp.ForeColor = System.Drawing.Color.White;
            this.buttonHelp.Image = ((System.Drawing.Image)(resources.GetObject("buttonHelp.Image")));
            this.buttonHelp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHelp.Location = new System.Drawing.Point(-9, -14);
            this.buttonHelp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonHelp.Name = "buttonHelp";
            this.buttonHelp.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.buttonHelp.Size = new System.Drawing.Size(261, 71);
            this.buttonHelp.TabIndex = 8;
            this.buttonHelp.Text = "               Help";
            this.buttonHelp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHelp.UseVisualStyleBackColor = false;
            this.buttonHelp.Click += new System.EventHandler(this.buttonHelp_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.buttonAbout);
            this.panel6.Location = new System.Drawing.Point(3, 278);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(243, 46);
            this.panel6.TabIndex = 9;
            // 
            // buttonAbout
            // 
            this.buttonAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(41)))), ((int)(((byte)(44)))));
            this.buttonAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAbout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAbout.ForeColor = System.Drawing.Color.White;
            this.buttonAbout.Image = ((System.Drawing.Image)(resources.GetObject("buttonAbout.Image")));
            this.buttonAbout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAbout.Location = new System.Drawing.Point(-9, -14);
            this.buttonAbout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAbout.Name = "buttonAbout";
            this.buttonAbout.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.buttonAbout.Size = new System.Drawing.Size(261, 71);
            this.buttonAbout.TabIndex = 8;
            this.buttonAbout.Text = "               About";
            this.buttonAbout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAbout.UseVisualStyleBackColor = false;
            this.buttonAbout.Click += new System.EventHandler(this.buttonAbout_Click);
            // 
            // sidebartimer
            // 
            this.sidebartimer.Interval = 10;
            this.sidebartimer.Tick += new System.EventHandler(this.siedbartimer_Tick);
            // 
            // fadeline
            // 
            this.fadeline.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.fadeline.AutoSizeMode = true;
            this.fadeline.BackColor = System.Drawing.Color.Transparent;
            this.fadeline.LineColor = System.Drawing.SystemColors.ButtonFace;
            this.fadeline.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.fadeline.Location = new System.Drawing.Point(472, 12);
            this.fadeline.Margin = new System.Windows.Forms.Padding(4);
            this.fadeline.Name = "fadeline";
            this.fadeline.Padding = new System.Windows.Forms.Padding(12, 11, 12, 11);
            this.fadeline.Size = new System.Drawing.Size(25, 790);
            this.fadeline.TabIndex = 4;
            this.fadeline.Click += new System.EventHandler(this.fadeline_Click);
            // 
            // dataGridView
            // 
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.Silver;
            this.dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenVertical;
            this.dataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Description,
            this.Category,
            this.StartDate,
            this.EndDate,
            this.Status});
            this.dataGridView.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.ControlDark;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridView.EnableHeadersVisualStyles = false;
            this.dataGridView.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dataGridView.Location = new System.Drawing.Point(508, 65);
            this.dataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.ActiveBorder;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.ControlDark;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridView.RowHeadersWidth = 82;
            this.dataGridView.Size = new System.Drawing.Size(856, 612);
            this.dataGridView.TabIndex = 5;
            this.dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.DarkSlateGray;
            this.Description.DefaultCellStyle = dataGridViewCellStyle21;
            this.Description.HeaderText = "Description ";
            this.Description.MinimumWidth = 10;
            this.Description.Name = "Description";
            this.Description.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Category
            // 
            this.Category.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Category.DefaultCellStyle = dataGridViewCellStyle22;
            this.Category.HeaderText = "Category";
            this.Category.MinimumWidth = 10;
            this.Category.Name = "Category";
            // 
            // StartDate
            // 
            this.StartDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StartDate.DefaultCellStyle = dataGridViewCellStyle23;
            this.StartDate.HeaderText = "Start Date";
            this.StartDate.MinimumWidth = 10;
            this.StartDate.Name = "StartDate";
            // 
            // EndDate
            // 
            this.EndDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.EndDate.DefaultCellStyle = dataGridViewCellStyle24;
            this.EndDate.HeaderText = "End Date";
            this.EndDate.MinimumWidth = 10;
            this.EndDate.Name = "EndDate";
            // 
            // Status
            // 
            this.Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Status.DefaultCellStyle = dataGridViewCellStyle25;
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 10;
            this.Status.Name = "Status";
            // 
            // AddButton
            // 
            this.AddButton.AllowFocus = false;
            this.AddButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddButton.Appearance.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.AddButton.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.25F);
            this.AddButton.Appearance.Options.UseBackColor = true;
            this.AddButton.Appearance.Options.UseFont = true;
            this.AddButton.Appearance.Options.UseTextOptions = true;
            this.AddButton.AppearanceHovered.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.AddButton.AppearanceHovered.Options.UseBackColor = true;
            this.AddButton.AutoSize = true;
            this.AddButton.AutoWidthInLayoutControl = true;
            this.AddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddButton.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("AddButton.ImageOptions.Image")));
            this.AddButton.Location = new System.Drawing.Point(1080, 12);
            this.AddButton.Margin = new System.Windows.Forms.Padding(4);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(96, 28);
            this.AddButton.TabIndex = 6;
            this.AddButton.Text = "Add Task";
            this.AddButton.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.AllowFocus = false;
            this.DeleteButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DeleteButton.Appearance.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.DeleteButton.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.25F);
            this.DeleteButton.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.DeleteButton.Appearance.Options.UseBackColor = true;
            this.DeleteButton.Appearance.Options.UseFont = true;
            this.DeleteButton.Appearance.Options.UseTextOptions = true;
            this.DeleteButton.AppearanceHovered.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.DeleteButton.AppearanceHovered.Options.UseBackColor = true;
            this.DeleteButton.AutoSize = true;
            this.DeleteButton.AutoWidthInLayoutControl = true;
            this.DeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DeleteButton.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("DeleteButton.ImageOptions.Image")));
            this.DeleteButton.Location = new System.Drawing.Point(1204, 12);
            this.DeleteButton.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(146, 28);
            this.DeleteButton.TabIndex = 8;
            this.DeleteButton.Text = "Delete Selected?";
            this.DeleteButton.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // Allbutton
            // 
            this.Allbutton.AllowFocus = false;
            this.Allbutton.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.False;
            this.Allbutton.Appearance.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Allbutton.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Allbutton.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Allbutton.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.Allbutton.Appearance.Options.UseFont = true;
            this.Allbutton.Appearance.Options.UseForeColor = true;
            this.Allbutton.AppearanceDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Allbutton.AppearanceDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Allbutton.AppearanceDisabled.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Allbutton.AppearanceDisabled.Options.UseFont = true;
            this.Allbutton.AppearanceDisabled.Options.UseForeColor = true;
            this.Allbutton.AppearanceHovered.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Allbutton.AppearanceHovered.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Allbutton.AppearanceHovered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Allbutton.AppearanceHovered.Options.UseFont = true;
            this.Allbutton.AppearanceHovered.Options.UseForeColor = true;
            this.Allbutton.AppearancePressed.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Allbutton.AppearancePressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Allbutton.AppearancePressed.Options.UseFont = true;
            this.Allbutton.AutoSize = true;
            this.Allbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Allbutton.Cursor = System.Windows.Forms.Cursors.Default;
            this.Allbutton.Location = new System.Drawing.Point(508, 17);
            this.Allbutton.Margin = new System.Windows.Forms.Padding(4);
            this.Allbutton.Name = "Allbutton";
            this.Allbutton.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.Allbutton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Allbutton.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.False;
            this.Allbutton.Size = new System.Drawing.Size(25, 27);
            this.Allbutton.TabIndex = 9;
            this.Allbutton.Text = "All";
            this.Allbutton.Click += new System.EventHandler(this.Addbutton_Click);
            // 
            // projectbutton
            // 
            this.projectbutton.AllowFocus = false;
            this.projectbutton.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.False;
            this.projectbutton.Appearance.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.projectbutton.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.projectbutton.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.projectbutton.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.projectbutton.Appearance.Options.UseFont = true;
            this.projectbutton.Appearance.Options.UseForeColor = true;
            this.projectbutton.AppearanceDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.projectbutton.AppearanceDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.projectbutton.AppearanceDisabled.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.projectbutton.AppearanceDisabled.Options.UseFont = true;
            this.projectbutton.AppearanceDisabled.Options.UseForeColor = true;
            this.projectbutton.AppearanceHovered.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.projectbutton.AppearanceHovered.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.projectbutton.AppearanceHovered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.projectbutton.AppearanceHovered.Options.UseFont = true;
            this.projectbutton.AppearanceHovered.Options.UseForeColor = true;
            this.projectbutton.AppearancePressed.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.projectbutton.AppearancePressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.projectbutton.AppearancePressed.Options.UseFont = true;
            this.projectbutton.AutoSize = true;
            this.projectbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.projectbutton.Cursor = System.Windows.Forms.Cursors.Default;
            this.projectbutton.Location = new System.Drawing.Point(775, 17);
            this.projectbutton.Margin = new System.Windows.Forms.Padding(4);
            this.projectbutton.Name = "projectbutton";
            this.projectbutton.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.projectbutton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.projectbutton.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.False;
            this.projectbutton.Size = new System.Drawing.Size(61, 27);
            this.projectbutton.TabIndex = 13;
            this.projectbutton.Text = "Projects";
            this.projectbutton.Click += new System.EventHandler(this.simpleButton6_Click);
            // 
            // workbutton
            // 
            this.workbutton.AllowFocus = false;
            this.workbutton.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.False;
            this.workbutton.Appearance.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.workbutton.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.workbutton.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.workbutton.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.workbutton.Appearance.Options.UseFont = true;
            this.workbutton.Appearance.Options.UseForeColor = true;
            this.workbutton.AppearanceDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.workbutton.AppearanceDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.workbutton.AppearanceDisabled.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.workbutton.AppearanceDisabled.Options.UseFont = true;
            this.workbutton.AppearanceDisabled.Options.UseForeColor = true;
            this.workbutton.AppearanceHovered.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.workbutton.AppearanceHovered.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.workbutton.AppearanceHovered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.workbutton.AppearanceHovered.Options.UseFont = true;
            this.workbutton.AppearanceHovered.Options.UseForeColor = true;
            this.workbutton.AppearancePressed.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.workbutton.AppearancePressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.workbutton.AppearancePressed.Options.UseFont = true;
            this.workbutton.AutoSize = true;
            this.workbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.workbutton.Cursor = System.Windows.Forms.Cursors.Default;
            this.workbutton.Location = new System.Drawing.Point(719, 17);
            this.workbutton.Margin = new System.Windows.Forms.Padding(4);
            this.workbutton.Name = "workbutton";
            this.workbutton.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.workbutton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.workbutton.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.False;
            this.workbutton.Size = new System.Drawing.Size(45, 27);
            this.workbutton.TabIndex = 14;
            this.workbutton.Text = "Work";
            this.workbutton.Click += new System.EventHandler(this.simpleButton7_Click);
            // 
            // Universitybutton
            // 
            this.Universitybutton.AllowFocus = false;
            this.Universitybutton.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.False;
            this.Universitybutton.Appearance.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Universitybutton.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Universitybutton.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Universitybutton.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.Universitybutton.Appearance.Options.UseFont = true;
            this.Universitybutton.Appearance.Options.UseForeColor = true;
            this.Universitybutton.AppearanceDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Universitybutton.AppearanceDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Universitybutton.AppearanceDisabled.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Universitybutton.AppearanceDisabled.Options.UseFont = true;
            this.Universitybutton.AppearanceDisabled.Options.UseForeColor = true;
            this.Universitybutton.AppearanceHovered.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Universitybutton.AppearanceHovered.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Universitybutton.AppearanceHovered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Universitybutton.AppearanceHovered.Options.UseFont = true;
            this.Universitybutton.AppearanceHovered.Options.UseForeColor = true;
            this.Universitybutton.AppearancePressed.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Universitybutton.AppearancePressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Universitybutton.AppearancePressed.Options.UseFont = true;
            this.Universitybutton.AutoSize = true;
            this.Universitybutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Universitybutton.Cursor = System.Windows.Forms.Cursors.Default;
            this.Universitybutton.Location = new System.Drawing.Point(632, 17);
            this.Universitybutton.Margin = new System.Windows.Forms.Padding(4);
            this.Universitybutton.Name = "Universitybutton";
            this.Universitybutton.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.Universitybutton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Universitybutton.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.False;
            this.Universitybutton.Size = new System.Drawing.Size(75, 27);
            this.Universitybutton.TabIndex = 15;
            this.Universitybutton.Text = "University";
            this.Universitybutton.Click += new System.EventHandler(this.Universitybutton_Click_1);
            // 
            // Personalbutton
            // 
            this.Personalbutton.AllowFocus = false;
            this.Personalbutton.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.False;
            this.Personalbutton.Appearance.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Personalbutton.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Personalbutton.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Personalbutton.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.Personalbutton.Appearance.Options.UseFont = true;
            this.Personalbutton.Appearance.Options.UseForeColor = true;
            this.Personalbutton.AppearanceDisabled.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Personalbutton.AppearanceDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Personalbutton.AppearanceDisabled.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Personalbutton.AppearanceDisabled.Options.UseFont = true;
            this.Personalbutton.AppearanceDisabled.Options.UseForeColor = true;
            this.Personalbutton.AppearanceHovered.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Personalbutton.AppearanceHovered.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Personalbutton.AppearanceHovered.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Personalbutton.AppearanceHovered.Options.UseFont = true;
            this.Personalbutton.AppearanceHovered.Options.UseForeColor = true;
            this.Personalbutton.AppearancePressed.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.Personalbutton.AppearancePressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.Personalbutton.AppearancePressed.Options.UseFont = true;
            this.Personalbutton.AutoSize = true;
            this.Personalbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Personalbutton.Cursor = System.Windows.Forms.Cursors.Default;
            this.Personalbutton.Location = new System.Drawing.Point(555, 17);
            this.Personalbutton.Margin = new System.Windows.Forms.Padding(4);
            this.Personalbutton.Name = "Personalbutton";
            this.Personalbutton.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.Personalbutton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Personalbutton.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.False;
            this.Personalbutton.Size = new System.Drawing.Size(65, 27);
            this.Personalbutton.TabIndex = 16;
            this.Personalbutton.Text = "Personal";
            this.Personalbutton.Click += new System.EventHandler(this.Personalbutton_Click_1);
            // 
            // buttonAll
            // 
            this.buttonAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAll.AutoSize = true;
            this.buttonAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAll.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAll.ForeColor = System.Drawing.Color.Black;
            this.buttonAll.Image = ((System.Drawing.Image)(resources.GetObject("buttonAll.Image")));
            this.buttonAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAll.Location = new System.Drawing.Point(85, 310);
            this.buttonAll.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAll.Name = "buttonAll";
            this.buttonAll.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.buttonAll.Size = new System.Drawing.Size(384, 70);
            this.buttonAll.TabIndex = 17;
            this.buttonAll.Text = "         All";
            this.buttonAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAll.UseMnemonic = false;
            this.buttonAll.UseVisualStyleBackColor = false;
            this.buttonAll.Click += new System.EventHandler(this.buttonAll_Click);
            // 
            // managebutton
            // 
            this.managebutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.managebutton.AutoSize = true;
            this.managebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.managebutton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.managebutton.ForeColor = System.Drawing.Color.Black;
            this.managebutton.Image = ((System.Drawing.Image)(resources.GetObject("managebutton.Image")));
            this.managebutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.managebutton.Location = new System.Drawing.Point(85, 610);
            this.managebutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.managebutton.Name = "managebutton";
            this.managebutton.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.managebutton.Size = new System.Drawing.Size(384, 70);
            this.managebutton.TabIndex = 18;
            this.managebutton.Text = "        Manage category";
            this.managebutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.managebutton.UseMnemonic = false;
            this.managebutton.UseVisualStyleBackColor = false;
            this.managebutton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // completebutton
            // 
            this.completebutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.completebutton.AutoSize = true;
            this.completebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.completebutton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.completebutton.ForeColor = System.Drawing.Color.Black;
            this.completebutton.Image = ((System.Drawing.Image)(resources.GetObject("completebutton.Image")));
            this.completebutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.completebutton.Location = new System.Drawing.Point(85, 460);
            this.completebutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.completebutton.Name = "completebutton";
            this.completebutton.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.completebutton.Size = new System.Drawing.Size(384, 70);
            this.completebutton.TabIndex = 19;
            this.completebutton.Text = "         Complete    ";
            this.completebutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.completebutton.UseMnemonic = false;
            this.completebutton.UseVisualStyleBackColor = false;
            this.completebutton.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Pendingbutton
            // 
            this.Pendingbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Pendingbutton.AutoSize = true;
            this.Pendingbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Pendingbutton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pendingbutton.ForeColor = System.Drawing.Color.Black;
            this.Pendingbutton.Image = ((System.Drawing.Image)(resources.GetObject("Pendingbutton.Image")));
            this.Pendingbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Pendingbutton.Location = new System.Drawing.Point(85, 385);
            this.Pendingbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pendingbutton.Name = "Pendingbutton";
            this.Pendingbutton.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.Pendingbutton.Size = new System.Drawing.Size(384, 70);
            this.Pendingbutton.TabIndex = 20;
            this.Pendingbutton.Text = "         Pending";
            this.Pendingbutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Pendingbutton.UseMnemonic = false;
            this.Pendingbutton.UseVisualStyleBackColor = false;
            this.Pendingbutton.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // separatorControl1
            // 
            this.separatorControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.separatorControl1.AutoSizeMode = true;
            this.separatorControl1.LineColor = System.Drawing.SystemColors.ButtonFace;
            this.separatorControl1.Location = new System.Drawing.Point(487, 43);
            this.separatorControl1.Margin = new System.Windows.Forms.Padding(4);
            this.separatorControl1.Name = "separatorControl1";
            this.separatorControl1.Padding = new System.Windows.Forms.Padding(12, 11, 12, 11);
            this.separatorControl1.Size = new System.Drawing.Size(879, 23);
            this.separatorControl1.TabIndex = 21;
            this.separatorControl1.Click += new System.EventHandler(this.separatorControl1_Click);
            // 
            // todobutton
            // 
            this.todobutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.todobutton.AutoSize = true;
            this.todobutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.todobutton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todobutton.ForeColor = System.Drawing.Color.Black;
            this.todobutton.Image = ((System.Drawing.Image)(resources.GetObject("todobutton.Image")));
            this.todobutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.todobutton.Location = new System.Drawing.Point(85, 535);
            this.todobutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.todobutton.Name = "todobutton";
            this.todobutton.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.todobutton.Size = new System.Drawing.Size(384, 70);
            this.todobutton.TabIndex = 22;
            this.todobutton.Text = "         todo...";
            this.todobutton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.todobutton.UseMnemonic = false;
            this.todobutton.UseVisualStyleBackColor = false;
            this.todobutton.Click += new System.EventHandler(this.todobutton_Click_1);
            // 
            // searchControl1
            // 
            this.searchControl1.Location = new System.Drawing.Point(860, 17);
            this.searchControl1.Margin = new System.Windows.Forms.Padding(4);
            this.searchControl1.Name = "searchControl1";
            this.searchControl1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchControl1.Properties.Appearance.Options.UseFont = true;
            this.searchControl1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Repository.ClearButton(),
            new DevExpress.XtraEditors.Repository.SearchButton(),
            new DevExpress.XtraEditors.Repository.MRUButton()});
            this.searchControl1.Properties.ShowDefaultButtonsMode = DevExpress.XtraEditors.Repository.ShowDefaultButtonsMode.AutoChangeSearchToClear;
            this.searchControl1.Properties.ShowMRUButton = true;
            this.searchControl1.Size = new System.Drawing.Size(212, 24);
            this.searchControl1.TabIndex = 23;
            this.searchControl1.SelectedIndexChanged += new System.EventHandler(this.searchControl1_SelectedIndexChanged);
            this.searchControl1.TextChanged += new System.EventHandler(this.separatorControl1_Click);
            this.searchControl1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchControl1_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1380, 686);
            this.Controls.Add(this.searchControl1);
            this.Controls.Add(this.sidebar);
            this.Controls.Add(this.todobutton);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.separatorControl1);
            this.Controls.Add(this.Pendingbutton);
            this.Controls.Add(this.completebutton);
            this.Controls.Add(this.managebutton);
            this.Controls.Add(this.buttonAll);
            this.Controls.Add(this.Personalbutton);
            this.Controls.Add(this.Universitybutton);
            this.Controls.Add(this.workbutton);
            this.Controls.Add(this.projectbutton);
            this.Controls.Add(this.Allbutton);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.fadeline);
            this.Controls.Add(this.calendar);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.calendar.CalendarTimeProperties)).EndInit();
            this.sidebar.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MenuButton)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fadeline)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.separatorControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchControl1.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraEditors.Controls.CalendarControl calendar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel sidebar;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox MenuButton;
        private System.Windows.Forms.Button buttonSetting;
        private System.Windows.Forms.Button buttonHelp;
        private System.Windows.Forms.Button buttonAbout;
        private System.Windows.Forms.Label labelMenu;
        private System.Windows.Forms.Timer sidebartimer;
        private DevExpress.XtraEditors.SeparatorControl fadeline;
        private System.Windows.Forms.DataGridView dataGridView;
        private DevExpress.XtraEditors.SimpleButton AddButton;
        private DevExpress.XtraEditors.SimpleButton DeleteButton;
        private DevExpress.XtraEditors.SimpleButton Allbutton;
        private DevExpress.XtraEditors.SimpleButton projectbutton;
        private DevExpress.XtraEditors.SimpleButton workbutton;
        private DevExpress.XtraEditors.SimpleButton Universitybutton;
        private DevExpress.XtraEditors.SimpleButton Personalbutton;
        private System.Windows.Forms.Button buttonAll;
        private System.Windows.Forms.Button managebutton;
        private System.Windows.Forms.Button completebutton;
        private System.Windows.Forms.Button Pendingbutton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private DevExpress.XtraEditors.SeparatorControl separatorControl1;
        private System.Windows.Forms.Button todobutton;
        private DevExpress.XtraEditors.SearchControl searchControl1;
    }
}

