﻿using DevExpress.ClipboardSource.SpreadsheetML;
using DevExpress.Data;
using DevExpress.XtraEditors.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using to_do_list___task_managment__.Data_Access;
using static DevExpress.Data.Helpers.ExpressiveSortInfo;

namespace to_do_list___task_managment__
{
    public partial class Form1 : Form
    {
        bool sidebarexpand;
        public Form1()
        {
            InitializeComponent();
        }
        private BindingSource bindingSource;
        public string filePath = Path.Combine(Application.StartupPath, "tasks");
        private void Form1_Load(object sender, EventArgs e)
        {
            CreateTasksFile();
            ManageTask manageTask = new ManageTask();
            manageTask.CreateCountFile();
            var tasks = ManageTask.LoadTasksFromFile(filePath);
            bindingSource = new BindingSource();
            bindingSource.DataSource = tasks;
            dataGridView.AutoGenerateColumns = false;
            dataGridView.DefaultCellStyle.SelectionBackColor = Color.DarkSalmon;
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            dataGridView.DefaultCellStyle.ForeColor = Color.Black;
            dataGridView.DataSource = bindingSource;

            // افزودن ستون‌ها به DataGridView
            dataGridView.Columns.Clear();
            dataGridView.Columns.Add(CreateTextBoxColumn("Description", "Description"));
            dataGridView.Columns.Add(CreateTextBoxColumn("Category", "Category"));
            dataGridView.Columns.Add(CreateTextBoxColumn("StartDate", "Start Date"));
            dataGridView.Columns.Add(CreateTextBoxColumn("EndDate", "End Date"));
            dataGridView.Columns.Add(CreateTextBoxColumn("Status", "Status"));

            // افزودن رویداد برای به‌روزرسانی فایل هنگام تغییر محتوا
            dataGridView.CellValueChanged += dataGridView1_CellContentClick;
        }

        private DataGridViewTextBoxColumn CreateTextBoxColumn(string typedata, string headerText)
        {
            return new DataGridViewTextBoxColumn
            {
                DataPropertyName = typedata,
                HeaderText = headerText,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            };
        }



        private void CreateTasksFile()
        {
            try
            {
                string directoryPath = Path.GetDirectoryName(filePath);

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while creating the tasks file: " + ex.Message);
            }
        }

        private void calendarControl1_DateChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = calendar.DateTime;
            FilterTasksByDate(selectedDate);
        }

        private void FilterTasksByDate(DateTime date)
        {
            var tasks = ManageTask.LoadTasksFromFile(filePath);
            var filteredTasks = tasks.Where(t => t.StartDate.Date == date.Date || t.EndDate.Date == date.Date).ToList();

            bindingSource.DataSource = filteredTasks;
        }

        private void calendarControl1_Click(object sender, EventArgs e)
        {

        }

        private void calendarControl1_Click_1(object sender, EventArgs e)
        {

        }

        private void calendarControl2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("coming soon...");
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void sidebartimer_Tick(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void siedbartimer_Tick(object sender, EventArgs e)
        {
            // change size of the sidebar...   
            if (sidebarexpand)
            {
                // if siedbar is opened...
                sidebar.Width -= 10;
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarexpand = false;
                    sidebartimer.Stop();
                }
            }
            else
            {
                // if siedbar is closed...
                sidebar.Width += 10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sidebarexpand = true;
                    sidebartimer.Stop();
                }
            }
        }

        private void MenuButton_Click(object sender, EventArgs e)
        {
            sidebartimer.Start();
        }

        private void fadeline_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var updatedTask = (Tasks)dataGridView.Rows[e.RowIndex].DataBoundItem;
                ManageTask.UpdateTask(filePath, updatedTask);
            }
        }


        private void simpleButton1_Click(object sender, EventArgs e)
        {
            var newTask = new Tasks
            {
                Description = "New Task",
                category = Data_Access.Tasks.Category.personal,
                StartDate = DateTime.Now.Date,
                EndDate = DateTime.Now.Date.AddDays(1),
                status = Data_Access.Tasks.Status.todo
            };
            bindingSource.Add(newTask);
            ManageTask.SaveTasksToFile(filePath, newTask);
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            List<Tasks> del = new List<Tasks>();

            foreach (DataGridViewRow row in dataGridView.SelectedRows)
            {
                if (row.DataBoundItem is Tasks task)
                {
                    del.Add(task);
                    bindingSource.Remove(task);
                }
            }

            ManageTask.DeleteTasksToFile(filePath, del);
        }

        private void dataGrid1_Navigate(object sender, NavigateEventArgs ne)
        {

        }

        private void Addbutton_Click(object sender, EventArgs e)
        {
            var allbutton = ManageTask.LoadTasksFromFile(filePath);
            bindingSource.DataSource = allbutton;
        }

        private void simpleButton7_Click(object sender, EventArgs e)
        {
            var work = ManageTask.LoadTasksFromFile(filePath);
            var _work = work.Where(t => t.category == Tasks.Category.work);
            bindingSource.DataSource = _work;
        }

        private void simpleButton6_Click(object sender, EventArgs e)
        {
            var projects = ManageTask.LoadTasksFromFile(filePath);
            var _projects = projects.Where(t => t.category == Tasks.Category.projects);
            bindingSource.DataSource = _projects;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void buttonAll_Click(object sender, EventArgs e)
        {
            var allbutton = ManageTask.LoadTasksFromFile(filePath);
            bindingSource.DataSource = allbutton;
        }

        private void dataNavigator1_Click(object sender, EventArgs e)
        {

        }

        private void officeNavigationBar1_Click(object sender, EventArgs e)
        {

        }

        private void buttonEdit1_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            var pendingbutton = ManageTask.LoadTasksFromFile(filePath);
            var _pendingbutton = pendingbutton.Where(t => t.status == Tasks.Status.pending);
            bindingSource.DataSource = _pendingbutton;

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            var completebutton = ManageTask.LoadTasksFromFile(filePath);
            var _completebutton = completebutton.Where(t => t.status == Tasks.Status.done);
            bindingSource.DataSource = _completebutton;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("coming soon...");
        }

        private void separatorControl1_Click(object sender, EventArgs e)
        {

        }

        private void Personalbutton_Click_1(object sender, EventArgs e)
        {
            var Personalbutton = ManageTask.LoadTasksFromFile(filePath);
            var _Personalbutton = Personalbutton.Where(t => t.category == Tasks.Category.personal);
            bindingSource.DataSource = _Personalbutton;

        }

        private void Universitybutton_Click_1(object sender, EventArgs e)
        {
            var Universitybutton = ManageTask.LoadTasksFromFile(filePath);
            var _Universitybutton = Universitybutton.Where(t => t.category == Tasks.Category.university);
            bindingSource.DataSource = _Universitybutton;
        }

        private void todobutton_Click_1(object sender, EventArgs e)
        {
            var todobutton = ManageTask.LoadTasksFromFile(filePath);
            var _todobutton = todobutton.Where(t => t.status == Tasks.Status.todo);
            bindingSource.DataSource = _todobutton;
        }

        private void searchControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var searchbox = ManageTask.LoadTasksFromFile(filePath);
            string searchtask = searchControl1.Text.ToLower();
            var _searchbox = searchbox.Where(t => t.Description.ToLower().Contains(searchtask)).ToList();
            bindingSource.DataSource = _searchbox;
        }

        private void searchControl1_KeyPress(object sender, KeyPressEventArgs e)
        {
            var searchbox = ManageTask.LoadTasksFromFile(filePath);
            string searchtask = searchControl1.Text.ToLower();
            var _searchbox = searchbox.Where(t => t.Description.ToLower().Contains(searchtask)).ToList();
            bindingSource.DataSource = _searchbox;
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ways of communication with support team:(email: 'arshia.dorrani@gmail.com'  --  phone: '09210882565'  --  telegram: 'Arshia17d')");
        }

        private void buttonAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("hey there👋 \n"+
                "I am Arshia. I was born in 2003 and I study computer engineering at the University of Sistan and Baluchistan. and learning c#.net, sql...");

        }

        private void buttonSetting_Click(object sender, EventArgs e)
        {
            MessageBox.Show("coming soon...");
        }
    }
}
