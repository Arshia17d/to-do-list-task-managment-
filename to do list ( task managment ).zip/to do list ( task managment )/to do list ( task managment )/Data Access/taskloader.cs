﻿using DevExpress.Utils.Text;
using DevExpress.XtraEditors.Mask;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using to_do_list___task_managment__.Data_Access;

namespace to_do_list___task_managment__
{
    public class ManageTask
    {
        static int ID;
        public static string _countid = Path.Combine(Application.StartupPath, "CountId.txt");
        public void CreateCountFile()
        {
            try
            {
                string directoryPath = Path.GetDirectoryName(_countid);

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                if (!File.Exists(_countid))
                {
                    File.Create(_countid).Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while creating the count file: " + ex.Message);
            }
        }

        public static int CountID(string countid)
        {
            if (File.Exists(countid))
            {
                var readid = File.ReadAllText(countid);
                if (int.TryParse(readid, out int parsedId))
                {
                    ID = parsedId;
                }
                else
                {
                    ID = 0; // مقدار پیش‌فرض در صورت عدم موفقیت در تبدیل
                }
            }
            return ID;
        }

        public static void UpdateID(string countid)
        {
            File.WriteAllText(countid, ID.ToString());
        }

        public static List<Tasks> LoadTasksFromFile(string filePath)
        {
            var tasks = new List<Tasks>();

            if (File.Exists(filePath))
            {
                var lines = File.ReadAllLines(filePath);

                foreach (var line in lines)
                {
                    var parts = line.Split(',');

                    if (parts.Length == 6)
                    {
                        var task = new Tasks
                        {
                            ID = int.Parse(parts[0]),
                            Description = parts[1],
                            StartDate = DateTime.Parse(parts[3]),
                            EndDate = DateTime.Parse(parts[4])
                        };

                        if (Enum.TryParse(parts[2], out Tasks.Category category))
                        {
                            task.category = category;
                        }
                        else
                        {
                            MessageBox.Show($"Invalid Category: {parts[2]}");
                            continue;
                        }

                        if (Enum.TryParse(parts[5], true, out Tasks.Status status))
                        {
                            task.status = status;
                        }
                        else
                        {
                            MessageBox.Show($"Invalid Status: {parts[5]}");
                            continue;
                        }
                        tasks.Add(task);
                    }
                }
            }
            else
            {
                MessageBox.Show("Task file not found.");
            }

            return tasks;
        }

        public static void SaveTasksToFile(string filePath, Tasks newTask)
        {
            ID = CountID(_countid);
            ID += 1;
            using (StreamWriter sw = File.AppendText(filePath))
            {
                sw.WriteLine(
                    $"{ID},{newTask.Description},{newTask.category},{newTask.StartDate},{newTask.EndDate},{newTask.status}"
                );
            }

            UpdateID(_countid);
        }

        public static void DeleteTasksToFile(string filepath, List<Tasks> tasks)
        {
            var mytasks = LoadTasksFromFile(filepath);
            foreach (var item in tasks)
            {
                mytasks.RemoveAll(
                    task =>
                        task.ID == item.ID
                        && task.Description == item.Description
                        && task.category == item.category
                        && task.StartDate == item.StartDate
                        && task.EndDate == item.EndDate
                        && task.status == item.status
                );
            }
            Savelisttask(filepath, mytasks);
        }

        public static void Savelisttask(string filePath, List<Tasks> tasks)
        {
            List<string> str = new List<string>();
            foreach (var item in tasks)
            {
                str.Add(
                    $"{item.ID},{item.Description},{item.category},{item.StartDate},{item.EndDate},{item.status}"
                );
            }

            File.WriteAllLines(filePath, str);
        }

        public static void UpdateTask(string filePath, Tasks updatedTask)
        {
            var allTasks = LoadTasksFromFile(filePath);
            var taskIndex = allTasks.FindIndex(t => t.ID == updatedTask.ID);

            if (taskIndex >= 0)
            {
                allTasks[taskIndex] = updatedTask;
                Savelisttask(filePath, allTasks);
            }
            else
            {
                MessageBox.Show("Task not found.");
            }
        }
    }
}
