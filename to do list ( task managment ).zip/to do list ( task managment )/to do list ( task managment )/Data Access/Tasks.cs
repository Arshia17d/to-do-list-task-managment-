﻿using DevExpress.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Security.Cryptography;

namespace to_do_list___task_managment__.Data_Access
{

    public class Tasks
    {
        public enum Category
        {
            personal,
            university,
            work,
            projects
        }
        public enum Status
        {
            done,
            todo,
            pending
        }
        public int ID { get; set; }
        public string Description { get; set; }
        public Category category { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public Status status { get; set; }
    }
}
